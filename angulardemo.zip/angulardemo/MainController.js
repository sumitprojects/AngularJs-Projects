var app = angular.module("myApp", []);


app.controller('MainController', ['$scope', function($scope) { 
  $scope.title = 'This Month\'s Bestsellers'; 
  $scope.promo = 'The most popular books this month.';
  $scope.quantity = 1;

  $scope.products = [
  	{ 
    	name: 'The Book of Trees', 
    	price: 19, 
    	pubdate: new Date('2014', '03', '08'), 
    	cover: 'img/product1.png',
      likes:0,
      dislikes:0
  	}, 
  	{ 
    	name: 'Program or be Programmed', 
    	price: 8, 
    	pubdate: new Date('2013', '08', '01'), 
    	cover: 'img/product2.png',
      likes:0,
      dislikes:0
  	},
    { 
    	name: 'Half Girlfriend', 
    	price: 20, 
    	pubdate: new Date('2014', '03', '08'), 
    	cover: 'img/product1.png',
      likes:0,
      dislikes:0
  	},
    { 
    	name: '2 States', 
    	price: 36, 
    	pubdate: new Date('2014', '03', '08'), 
    	cover: 'img/product2.png',
      likes:0,
      dislikes:0
  	}
  ];
  $scope.plusOne = function(index){
    $scope.products[index].likes += 1;
  } 
   $scope.minusOne = function(index){
    $scope.products[index].dislikes += 1;
    return $scope.products[index].dislikes;
  } 

}]);
