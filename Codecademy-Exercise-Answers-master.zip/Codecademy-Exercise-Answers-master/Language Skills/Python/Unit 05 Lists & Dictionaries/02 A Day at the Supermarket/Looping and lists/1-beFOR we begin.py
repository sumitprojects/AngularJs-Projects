names = ["Adam","Alex","Mariah","Martine","Columbus"]

for word in names:
    print word
