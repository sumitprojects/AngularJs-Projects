groceries = ["banana","orange","apple"]
