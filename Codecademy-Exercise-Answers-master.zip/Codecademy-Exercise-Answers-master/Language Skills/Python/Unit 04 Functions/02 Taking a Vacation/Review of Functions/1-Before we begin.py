def answer():
    return 42
