def list_function(x):
    return x

n = [3, 5, 7]
print list_function(n)
