n = [1, 3, 5]
# Append the number 4 here
n.append(4)
print n
