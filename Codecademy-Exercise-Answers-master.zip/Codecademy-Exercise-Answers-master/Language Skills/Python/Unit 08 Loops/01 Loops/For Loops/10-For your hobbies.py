hobbies = []

# Add your code below!
for a in range(3):
    i = raw_input('Select a hobbie')

    hobbies.append(i)
print hobbies
