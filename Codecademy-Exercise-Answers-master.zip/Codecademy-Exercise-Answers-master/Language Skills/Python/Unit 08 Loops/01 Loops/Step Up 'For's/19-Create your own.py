Aline = ['danca', 'corre', 'platina', 'feeda']

for a in Aline:
    if a == 'feeda' or a == 'platina':
        print a, 'EOQ'

    else:
        print a, 'MENTIRA'
