num = 1

while num <= 10:  # Fill in the condition
    x = num ** 2# Print num squared
    num = num + 1# Increment num (make sure to do this!)
    print x
    print num
