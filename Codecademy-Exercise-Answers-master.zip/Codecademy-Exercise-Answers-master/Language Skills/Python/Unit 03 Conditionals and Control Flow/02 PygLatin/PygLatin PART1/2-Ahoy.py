print 'Pig Latin'
