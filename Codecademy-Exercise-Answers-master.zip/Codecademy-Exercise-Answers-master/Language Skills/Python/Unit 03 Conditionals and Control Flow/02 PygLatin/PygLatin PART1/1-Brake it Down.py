def ral
raw = raw_input('TELL ME a word in ENGRIXH').lower()
    if raw != str
        return 'NOOO, IN engrixs'
        ral
    
