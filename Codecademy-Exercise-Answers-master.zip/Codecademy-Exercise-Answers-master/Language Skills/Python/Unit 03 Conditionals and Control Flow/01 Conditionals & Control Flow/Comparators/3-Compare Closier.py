# Assign True or False as appropriate on the lines below!

# (20 - 10) > 15
bool_one = False    # We did this one for you!

# (10 + 17) == 3**16
# Remember that ** can be read as 'to the power of'. 3**16 is about 43 million.
bool_two = (10+17)>3**16
print str(bool_two)

# 1**2 <= -1
bool_three = 1**2 <= -1
print str(bool_three)

# 40 * 4 >= -4
bool_four = 40*4 >=-4
print str(bool_four)

# 100 != 10**2
bool_five = 100 != 10**2
print bool_five
