print "Welcome to Python!"
