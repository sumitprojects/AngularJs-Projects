# Write your code below!
my_variable = 10
