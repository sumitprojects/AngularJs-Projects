spam = True
eggs = False
