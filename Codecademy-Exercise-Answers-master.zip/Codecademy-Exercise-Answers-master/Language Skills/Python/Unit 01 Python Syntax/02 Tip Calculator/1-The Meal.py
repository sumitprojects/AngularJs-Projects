# Assign the variable meal the value 44.50 on line 3!

meal = 44.50
