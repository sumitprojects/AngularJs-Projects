with open("text.txt", "w") as textfile:
	textfile.write("Success!")
