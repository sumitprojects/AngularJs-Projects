a = 0b11101110
mask = 0b11111111
result =(a^mask)
print bin(result)
