squares = [x**2 for x in range(1,11)]
print filter (lambda x: 30 <= x <= 70 , squares)
