languages = ["HTML", "JavaScript", "Python", "Ruby"]
print filter(lambda a: a == 'Python', languages)
