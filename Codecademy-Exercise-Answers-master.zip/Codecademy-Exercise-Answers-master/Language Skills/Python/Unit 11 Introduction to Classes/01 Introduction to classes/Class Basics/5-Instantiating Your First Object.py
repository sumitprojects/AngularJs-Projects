class Animal(object):
    def __init__(self, name):
        self.name = name
        pass

zebra = Animal("Jeffrey")
print zebra.name
