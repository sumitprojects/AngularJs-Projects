print "Let's compute some stats!"
