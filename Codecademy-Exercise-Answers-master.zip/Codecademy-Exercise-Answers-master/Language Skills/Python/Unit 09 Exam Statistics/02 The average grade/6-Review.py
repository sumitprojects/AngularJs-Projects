print "Time to conquer the variance!"
