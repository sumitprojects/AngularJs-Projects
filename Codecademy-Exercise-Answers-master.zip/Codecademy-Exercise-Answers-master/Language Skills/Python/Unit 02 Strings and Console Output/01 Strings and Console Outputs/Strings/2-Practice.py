# Assign your variables below, each on its own line!
caesar = "Graham"
praline = "John"
viking = "Teresa"


# Put your variables above this line

print caesar
print praline
print viking
