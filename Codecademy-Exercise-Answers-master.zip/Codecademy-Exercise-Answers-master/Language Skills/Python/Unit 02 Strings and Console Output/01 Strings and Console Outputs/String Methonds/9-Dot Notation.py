ministry = "The Ministry of Silly Walks"

print len(ministry)
print ministry.upper()
