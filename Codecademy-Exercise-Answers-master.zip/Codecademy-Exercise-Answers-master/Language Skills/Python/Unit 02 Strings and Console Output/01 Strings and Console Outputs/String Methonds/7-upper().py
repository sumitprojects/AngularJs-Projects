parrot = "norwegian blue"

print parrot.upper()
