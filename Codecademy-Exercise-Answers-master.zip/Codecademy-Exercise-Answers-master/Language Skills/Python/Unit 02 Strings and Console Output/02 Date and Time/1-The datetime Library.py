from datetime import datetime
print datetime.datetime
