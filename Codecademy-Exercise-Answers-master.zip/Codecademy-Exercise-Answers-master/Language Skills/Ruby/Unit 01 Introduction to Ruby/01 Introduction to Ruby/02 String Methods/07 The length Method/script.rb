"Sassafras".length
