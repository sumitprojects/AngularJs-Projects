name = "Sam"
name.downcase
name.reverse
name.upcase
