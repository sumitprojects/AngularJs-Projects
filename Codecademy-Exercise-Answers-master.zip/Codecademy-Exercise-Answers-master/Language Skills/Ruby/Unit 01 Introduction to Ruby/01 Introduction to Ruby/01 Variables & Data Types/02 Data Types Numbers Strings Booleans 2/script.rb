my_num = 25    # Add your code here!
my_boolean = true     # And here!
my_string =  "Ruby"   # Also here.
