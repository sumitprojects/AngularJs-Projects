# test_1 should be true
test_1 = 3 < 3 || 3<4

# test_2 = should be true
test_2 = ! ! true 

# test_3 = should be false
test_3 = 3 >1 && 3 == 2