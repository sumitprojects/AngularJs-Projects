def greeter(name)
    return "greetings " +name
end

def by_three?(number)
    if number % 3 == 0
        return true;
    else
        return false;
    end
end
