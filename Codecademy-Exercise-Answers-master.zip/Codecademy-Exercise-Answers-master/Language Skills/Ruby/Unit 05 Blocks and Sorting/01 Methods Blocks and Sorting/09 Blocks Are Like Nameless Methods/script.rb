1.times do
  puts "I'm a code block!"
end

1.times { puts "As am I!" }
