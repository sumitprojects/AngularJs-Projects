def add(n,m)
    return n+m
end
add(2,1)
