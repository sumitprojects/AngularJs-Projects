array = [1,2,3,4,5]

array.each do |x|
  x += 10
  print "#{x}"
end