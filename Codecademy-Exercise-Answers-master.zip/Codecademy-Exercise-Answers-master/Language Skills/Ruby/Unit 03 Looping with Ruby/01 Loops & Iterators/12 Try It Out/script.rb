odds = [1,3,5,7,9]

odds.each { |item| print item * 2 }