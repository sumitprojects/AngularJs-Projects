puts "input: "
text = gets.chomp
words = text.split
