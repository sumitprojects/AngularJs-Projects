languages = ["HTML", "CSS", "JavaScript", "Python", "Ruby"]
languages.each { |x| puts x}
