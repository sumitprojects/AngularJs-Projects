public class IfElse {
	public static void main(String[] args) {

		if (7 < 7) {

			System.out.println("Try again...");

		} else {

			System.out.println("Success!");

		}

	}
}
