import java.util.ArrayList;

public class Temperatures {

	public static void main(String[] args) {
		ArrayList<Integer> weeklyTemperatures = new ArrayList<Integer>();

	}
}
