public class For {
	public static void main(String[] args) {

		for (int waterLevel = 0; waterLevel < 7; waterLevel++){

			System.out.println("The pool's water level is at " + waterLevel + " feet.");

		}

	}

}
